﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Gozareshe_mogheiyate_objecte_Moteharrek
    {
    public partial class Form1 : Form
        {
        public Form1()
            {
            InitializeComponent();

            }

        private void Form1_Load(object sender, EventArgs e)
            {
           

            }

        private void timer1_Tick(object sender, EventArgs e)
            {
            //تعریف تابع رندوم برای استفاده در حرکات رندوم
            Random rnd1 = new Random();
            //تغییر مکان آبجکت
            panel1.Location = new Point(rnd1.Next(100, 800), rnd1.Next(100, 800));
            //نشان دادن مختصات در لیبل
            label3.Text = new Point(panel1.Location.X, panel1.Location.Y).ToString();
            // نشان دادن مختصات در لیست 
            listBox1.Items.Add(new Point(panel1.Location.X, panel1.Location.Y).ToString());  
            }

        private void btn_start_Click(object sender, EventArgs e)
            {
            //اگر پنل یا آبجکت در مختصات نابرابر بود تایمر کار می کنداما اگر در مختصات مورد نظر بود تایمر متوقف میشود 
            
                timer1.Enabled = true;
                timer1.Interval = 100;
                timer1.Start();
               
             if(panel1.Location.X <300  && panel1.Location.Y<400)
             {
                timer1.Stop();
                listBox1.Items.Add("Target Founded");
             } 
            }
        }
    }
